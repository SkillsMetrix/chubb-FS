import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DdForm } from './components/dd-form/dd-form';
import { UserDetails } from './components/user-details/user-details';
import { Login } from './components/login/login';
import { UserDashboard } from './components/user-dashboard/user-dashboard';
import { RegistryPolicy } from './components/registry-policy/registry-policy';
import { ActivePolicy } from './components/active-policy/active-policy';

const routes: Routes = [
  {path:'', component:Login},
  {path:'login', component:Login},
  {path:'add', component:DdForm},
   {path:'load', component:UserDetails},
   {path:'ud', component:UserDashboard},
   {path:'rp', component:RegistryPolicy},
   {path:'ap', component:ActivePolicy}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
