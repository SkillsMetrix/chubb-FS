import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
 import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import {MatTabsModule} from '@angular/material/tabs';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
@NgModule({
  declarations: [],
  exports: [
   MatButtonModule,MatInputModule,MatSelectModule,MatFormFieldModule,MatCardModule,CommonModule,MatTabsModule,MatToolbarModule,MatIconModule,
   MatDividerModule
  ]
})
export class MaterialModule { }
