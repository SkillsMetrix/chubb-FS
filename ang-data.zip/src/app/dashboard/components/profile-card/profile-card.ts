import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-profile-card',
  standalone: false,
  templateUrl: './profile-card.html',
  styleUrl: './profile-card.css',
})
export class ProfileCard implements OnChanges{

  @Input()
  profile:any
  initials=''

  ngOnChanges(): void {
    if(this.profile?.fullName){
      const names= this.profile.fullName.trim().split(' ')
      this.initials=names.length >1 ? names[0][0] + names[1][0] : names[0][0]
      this.initials=this.initials.toUpperCase()
      console.log(this.initials);
      
    }
  }
}
