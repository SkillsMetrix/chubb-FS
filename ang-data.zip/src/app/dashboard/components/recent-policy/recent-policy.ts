import { Component } from '@angular/core';

@Component({
  selector: 'app-recent-policy',
  standalone: false,
  templateUrl: './recent-policy.html',
  styleUrl: './recent-policy.css',
})
export class RecentPolicy {

}
