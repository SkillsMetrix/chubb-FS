import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Mainapp } from './components/mainapp/mainapp';
import { Header } from './components/header/header';
import { Footer } from './components/footer/footer';
import { TemplateForm } from './components/template-form/template-form';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { DdForm } from './components/dd-form/dd-form';
import { HttpClientModule } from '@angular/common/http';
import { UserDetails } from './components/user-details/user-details';
import { MaterialModule } from './material/material-module';
import { Navbar } from './components/navbar/navbar';
import { Login } from './components/login/login';
import { UserDashboard } from './components/user-dashboard/user-dashboard';
import { RegistryPolicy } from './components/registry-policy/registry-policy';
import { ActivePolicy } from './components/active-policy/active-policy';
import { PolicyDetails } from './components/policy-details/policy-details';
import { ProfileCard } from './dashboard/components/profile-card/profile-card';
import { SummaryCard } from './dashboard/components/summary-card/summary-card';
import { RecentPolicy } from './dashboard/components/recent-policy/recent-policy';
@NgModule({
  declarations: [
    App,
    Mainapp,
    Header,
    Footer,
    TemplateForm,
    DdForm,
    UserDetails,
    Navbar,
    Login,
    UserDashboard,
    RegistryPolicy,
    ActivePolicy,
    PolicyDetails,
    ProfileCard,
    SummaryCard,
    RecentPolicy
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    AppRoutingModule,FormsModule,
    ReactiveFormsModule,HttpClientModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
  ],
  bootstrap: [App]
})
export class AppModule { }
