import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  private readonly USERNAME_KEY='username'
  isLoggedIn= false;
  username=''

  constructor(){}
  getUserName(){
    return this.username
  }
  isAuthticated(){
    return this.isAuthticated
  }
  restoreSession(){
    const user= sessionStorage.getItem(this.USERNAME_KEY)
  }
  login(name:string){
    this.isLoggedIn=true
    this.username=name
    sessionStorage.setItem(this.USERNAME_KEY,this.username)
  }
  logout(){
    this.isLoggedIn=false
    this.username=''
    sessionStorage.removeItem(this.USERNAME_KEY)
  }
}
