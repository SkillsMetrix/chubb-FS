import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
const URL = 'http://127.0.0.1:8084/emp';
@Injectable({
  providedIn: 'root',
})
export class FormService {
  constructor(private http: HttpClient) {}

  addUserToDB(udata: any) {
    this.http.post(`${URL}/addemp`, udata).subscribe((data) => console.log(data));
  }
  loadUsersFromDB() {
    return this.http.get<any[]>(`${URL}/getemp`);
  }

  getProfile(username: string): Observable<any> {
    return this.http.get<any[]>(`${URL}/profile/${username}`);
  }

  login(udata: any) {
    return this.http.post(`${URL}/login`, udata);
  }
}
