import { Injectable } from '@angular/core';
import { Student } from '../model/Student';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  loadStudents(): Student[] {
    return [new Student(101, 'Rahul', 21, 'BCA'),
         new Student(102, 'Piyush', 21, 'MCA')];
  }
}
