import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  loadUsers(): string[] {
    return ['admin', 'manager', 'qa'];
  }
}
