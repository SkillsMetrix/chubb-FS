import { Component, OnInit } from '@angular/core';
import { FormService } from '../../services/Form.service';

@Component({
  selector: 'app-user-details',
  standalone: false,
  templateUrl: './user-details.html',
  styleUrl: './user-details.css',
})
export class UserDetails implements OnInit {
  employees:any[]=[]
 
  
  constructor(private fs:FormService){}
 
  
  ngOnInit(): void {
    this.loadEmployees()
    
    
  }
 
  
  loadEmployees(){
    this.fs.loadUsersFromDB().subscribe({
      next: (data)=> {
        console.log('from server ',data);
        
        this.employees=data
         console.log(this.employees);
      }
    }
    )
   
    
  }

}
