import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormService } from '../../services/Form.service';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  
  constructor(private fs:FormService,private router:Router,private au:Auth){}

  login(nf:NgForm){
    this.fs.login(nf.value).subscribe({
      next:()=>{
        this.au.login(nf.value.uname)
          this.router.navigate(['/ud'])
      }
    })
  }

}
