import { Component } from '@angular/core';

@Component({
  selector: 'app-mainapp',
  standalone: false,
  templateUrl: './mainapp.html',
  styleUrl: './mainapp.css',
})
export class Mainapp {

}
