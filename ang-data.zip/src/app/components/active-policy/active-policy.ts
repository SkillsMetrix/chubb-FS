import { Component } from '@angular/core';

@Component({
  selector: 'app-active-policy',
  standalone: false,
  templateUrl: './active-policy.html',
  styleUrl: './active-policy.css',
})
export class ActivePolicy {

}
