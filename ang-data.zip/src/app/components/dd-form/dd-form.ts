import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../../services/Form.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dd-form',
  standalone: false,
  templateUrl: './dd-form.html',
  styleUrl: './dd-form.css',
})
export class DdForm {
  departments = ['IT', 'Finance', 'HR', 'Sales'];
  roles = ['ADMIN', 'MANAGER', 'QA', 'Sr.Manager'];
  empForm!: FormGroup;
  constructor(private fb: FormBuilder,private fs:FormService,private route:Router) {
    this.empForm = this.fb.group({
      uname: ['',[Validators.required]],
      email: ['',[Validators.required,Validators.email]],
      password: [''],
      department: [''],
      fullName: [''],
      city: [''],
      mobile: [''],
      role: [''],
    });
  }
  get f() {
    return this.empForm.controls;
  }
  saveEmp() {
    this.fs.addUserToDB(this.empForm.value)
    alert('User Registered')
    this.route.navigate(['/login'])
 
  }

}
