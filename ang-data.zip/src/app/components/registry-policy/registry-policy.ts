import { Component } from '@angular/core';

@Component({
  selector: 'app-registry-policy',
  standalone: false,
  templateUrl: './registry-policy.html',
  styleUrl: './registry-policy.css',
})
export class RegistryPolicy {

}
