import { Component } from '@angular/core';
import { Auth } from '../../services/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: false,
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
  
constructor( public au:Auth,private route:Router){}
logout(){
  this.au.logout()
  this.route.navigate(['/'])
}
}
