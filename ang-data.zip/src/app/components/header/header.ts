import { Component } from '@angular/core';
import { UserService } from '../../services/User.service';
import { StudentService } from '../../services/Student.service';
import { Student } from '../../model/Student';

@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {
  // dependency injection
  constructor(private us:UserService,private sc:StudentService){
    this.users=this.us.loadUsers()
    this.students=this.sc.loadStudents()
  }

  users
  students: Student[]

}
