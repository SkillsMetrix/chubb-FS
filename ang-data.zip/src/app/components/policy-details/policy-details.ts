import { Component } from '@angular/core';

@Component({
  selector: 'app-policy-details',
  standalone: false,
  templateUrl: './policy-details.html',
  styleUrl: './policy-details.css',
})
export class PolicyDetails {

}
