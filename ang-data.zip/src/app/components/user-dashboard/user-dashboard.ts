import { Component, OnInit } from '@angular/core';
import { Auth } from '../../services/auth';
import { FormService } from '../../services/Form.service';

@Component({
  selector: 'app-user-dashboard',
  standalone: false,
  templateUrl: './user-dashboard.html',
  styleUrl: './user-dashboard.css',
})
export class UserDashboard implements OnInit{
  profile:any
  constructor( public au:Auth,private fs:FormService){}
  ngOnInit(): void {
    const username= this.au.getUserName()
    this.fs.getProfile(username).subscribe({
      next:(response)=>{
        this.profile=response
        console.log(this.profile);
        
      }
    })
  }
}
