import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-template-form',
  standalone: false,
  templateUrl: './template-form.html',

  styleUrl: './template-form.css',
})
export class TemplateForm {

  saveEmp(nf:NgForm){
    console.log(nf.value);
    
  }
  departments=['IT','Finance','HR','Sales']
}
