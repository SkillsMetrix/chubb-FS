package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Employee;
import com.service.EmployeeService;

@RestController
@RequestMapping("/chubb")
public class RestApp {
	
	// Inject the Dependency using DI (dependency Injection)
	@Autowired
	private EmployeeService service;
	 
	@GetMapping("/loadusers")
	public List<Employee> loadUsers() {
		return service.loadUsers();
	}
	
	@GetMapping("/loadusers/{id}")
	public boolean loadUser(@PathVariable int id) {
		return service.loadUser(id);
	}
	@GetMapping("/deleteuser/{id}")
	public boolean deleteUser(@PathVariable int id) {
		return service.deleteUser(id);
	}
	@PostMapping("/register")
	public void addUser(@RequestBody Employee employee ) {
		service.registerUser(employee);
	}
	
}
