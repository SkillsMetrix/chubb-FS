package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
// spring takes care of object creation using Factory pattern
// the object is created by spring is always remain singleton
// this annotation is designed to hold BL

import com.model.Employee;

@Service
public class EmployeeService {

	List<Employee> al = new ArrayList<Employee>();

	public void registerUser(Employee employee) {
		al.add(employee);
	}

	public List<Employee> loadUsers() {
		return al;
	}

	public boolean loadUser(int empID) {

		for (Employee employee : al) {
			if (employee.getEmpId() == empID) {
				return true;}}
		return false;}
	
public boolean deleteUser(int empID) {
		
		for(Employee employee: al) {
			if(employee.getEmpId() == empID) {
				al.remove(empID);
				return true;
			} }
		return false;

	}

}
