package decorator;

public class BasicAccountService implements AccountService{

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Saving Account";
	}

	@Override
	public double getAnnualCharges() {
		// TODO Auto-generated method stub
		return 500;
	}

}
