package decorator;

public class InternetBankingDecorator {

}
