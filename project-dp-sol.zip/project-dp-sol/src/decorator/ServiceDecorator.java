package decorator;

public abstract class ServiceDecorator implements AccountService {
	
	public AccountService accountService;

	public ServiceDecorator(AccountService accountService) {
		 
		this.accountService = accountService;
	}
	
	

}
