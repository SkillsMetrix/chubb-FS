package decorator;

public interface AccountService {
	
	String getDescription();
	double getAnnualCharges();

}
