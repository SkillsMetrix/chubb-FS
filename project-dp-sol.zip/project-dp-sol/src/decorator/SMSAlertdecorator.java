package decorator;

public class SMSAlertdecorator extends ServiceDecorator{

	public SMSAlertdecorator(AccountService accountService) {
		super(accountService);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "SMS Charges Service";
	}

	@Override
	public double getAnnualCharges() {
		// TODO Auto-generated method stub
		return accountService.getAnnualCharges()+100;
	}

}
