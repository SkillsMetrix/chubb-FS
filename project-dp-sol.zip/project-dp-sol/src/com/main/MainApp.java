package com.main;

import config.BankConfiguration;
import decorator.AccountService;
import decorator.BasicAccountService;
import decorator.SMSAlertdecorator;
import factory.AccountFactory;
import model.BankAccount;
import strategy.CurrentInterestStrategy;
import strategy.FixedDepositInterestStrategy;
import strategy.SavingsInterestStrategy;

public class MainApp {
	
	// strategy Pattern
	// Interface segration pattern
	// Runtime poly
	// sep of bl
	

	public static void main(String[] args) {
		
			// Interest Calculation
			BankConfiguration config= BankConfiguration.getInstance();
			System.out.println(config.getBankName());
			System.out.println(config.getIfscCode());
			System.out.println(config.getCustomerCare());
		
			BankAccount savings= AccountFactory.createAccount("savings");
			System.out.println(savings.getAccountType());
			
			System.out.println(savings.calculateInterest(100000));
				
			// services TOPup
			AccountService service= new BasicAccountService();
			System.out.println("No Frills "+ service.getAnnualCharges());
			service= new SMSAlertdecorator(service);
			System.out.println("with SMS "+ service.getAnnualCharges());
			
			
			
			
			
		/*
		 * BankAccount savings= new BankAccount("Savings",new
		 * SavingsInterestStrategy());
		 * 
		 * BankAccount current= new BankAccount("Current",new
		 * CurrentInterestStrategy()); BankAccount fd= new BankAccount("Savings",new
		 * FixedDepositInterestStrategy());
		 * System.out.println(savings.calculateInterest(100000));
		 * System.out.println(current.calculateInterest(100000));
		 * System.out.println(fd.calculateInterest(100000));
		 */
	}

}
