package strategy;

public class FixedDepositInterestStrategy implements InterestStrategy{

	@Override
	public double calculateInterest(double balance) {
		// TODO Auto-generated method stub
		return balance * 0.07;
	}
}
