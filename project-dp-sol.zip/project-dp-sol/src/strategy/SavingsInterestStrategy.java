package strategy;

public class SavingsInterestStrategy implements InterestStrategy{

	@Override
	public double calculateInterest(double balance) {
		// TODO Auto-generated method stub
		return balance * 0.04;
	}

}
