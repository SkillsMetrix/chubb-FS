package model;

import strategy.InterestStrategy;

public class BankAccount {
	
	private String accountType;
	private InterestStrategy interestStrategy;
	public BankAccount(String accountType, InterestStrategy interestStrategy) {
		super();
		this.accountType = accountType;
		this.interestStrategy = interestStrategy;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public InterestStrategy getInterestStrategy() {
		return interestStrategy;
	}
	public void setInterestStrategy(InterestStrategy interestStrategy) {
		this.interestStrategy = interestStrategy;
	}
	public double calculateInterest(double balance) {
		return interestStrategy.calculateInterest(balance);
	}

}
