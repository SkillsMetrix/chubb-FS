package config;

public class BankConfiguration {

	private static final BankConfiguration INSTANCE= new BankConfiguration();
	
	private String bankName;
	private String ifscCode;
	private String customerCare;
	
	private BankConfiguration() {
		bankName="ChuBB Banking";
		ifscCode="CHUBB1234";
		customerCare="1800-890-4567";
		System.out.println("Loading Bank Configuration.....!");
	}
	public static BankConfiguration getInstance() {
		return INSTANCE;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getCustomerCare() {
		return customerCare;
	}
	public void setCustomerCare(String customerCare) {
		this.customerCare = customerCare;
	}
	
}
