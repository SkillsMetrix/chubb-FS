package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import model.BankAccount;
import strategy.SavingsInterestStrategy;

public class BankTest {
	
	@Test
	public void testSaving() {
		
		BankAccount account= new BankAccount("Savings", new SavingsInterestStrategy());
		
		assertEquals(4000, account.calculateInterest(100000));
		
	}

}
