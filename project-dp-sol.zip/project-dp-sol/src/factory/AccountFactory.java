package factory;

import model.BankAccount;
import strategy.CurrentInterestStrategy;
import strategy.FixedDepositInterestStrategy;
import strategy.SavingsInterestStrategy;

public class AccountFactory {
	
	public static BankAccount createAccount(String accountType) {
		
		switch (accountType.toLowerCase()) {
		case "savings": 
			return new BankAccount("Savings Account", new SavingsInterestStrategy());
		case "current": 
			return new BankAccount("Current Account", new CurrentInterestStrategy());
		case "fd": 
			return new BankAccount("Fixed Deposit Account", new FixedDepositInterestStrategy());
		default:
			throw new IllegalArgumentException("Invalid Acc Type");
			 

}
}}