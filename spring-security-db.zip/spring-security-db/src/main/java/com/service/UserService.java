package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.entity.AppUser;
import com.repo.UserRepo;

@Service
public class UserService implements UserDetailsService {
	@Autowired
	private UserRepo repo;
	@Autowired
	PasswordEncoder encoder;
	
	public void addUser(String name,String pass,String role) {
		AppUser appUser= new AppUser(name, encoder.encode(pass), role);
		System.out.println(appUser);
		repo.save(appUser);
	}
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		AppUser appUser= repo.findByUsername(username).orElseThrow(()-> new UsernameNotFoundException("User not found"));
		
		return User.builder()
				.username(appUser.getUsername())
				.password(appUser.getPassword())
				.roles(appUser.getRole())
				.build();
	}

}
