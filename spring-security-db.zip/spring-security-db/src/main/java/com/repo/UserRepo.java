package com.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.AppUser;
@Repository
public interface UserRepo extends JpaRepository<AppUser, Integer>{
	Optional<AppUser> findByUsername(String username);
}
