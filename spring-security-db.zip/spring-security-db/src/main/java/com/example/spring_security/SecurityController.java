package com.example.spring_security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.service.UserService;

//if you client is page
@Controller
// if your client is nonpage/angular/react ,you use @restcontroller
public class SecurityController {
	@Autowired
	private UserService service;
	
	@GetMapping("/home")
	public String index() {
		return "home";
	}
	@PostMapping("/saveUser")
	public String addUser(@RequestParam String username,@RequestParam String password,@RequestParam String role) {
		service.addUser(username, password, role);
		return "redirect:/login";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@GetMapping("/admin")
	public String admin() {
		return "admin";
	}
	@GetMapping("/student")
	public String student() {
		return "student";
	}
	@GetMapping("/trainer")
	public String trainer() {
		return "trainer";
	}
	@GetMapping("/access-denied")
	public String ad() {
		return "access-denied";
	}
}
